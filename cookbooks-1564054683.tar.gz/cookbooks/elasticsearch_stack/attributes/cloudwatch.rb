# frozen_string_literal: true

default['cloudwatch']['region'] = 'eu-west-1'
default['cloudwatch']['group']  = 'elasticsearch'
