# frozen_string_literal: true

default['metricbeat']['version']                             = '7.2.0'
default['metricbeat']['conf_path']                           = '/etc/metricbeat'
