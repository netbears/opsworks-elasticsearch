# frozen_string_literal: true

default['filebeat']['version']                             = '7.2.0'
default['filebeat']['conf_path']                           = '/etc/filebeat'
