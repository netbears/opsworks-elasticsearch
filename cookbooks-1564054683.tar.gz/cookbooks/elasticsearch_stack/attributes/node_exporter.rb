# frozen_string_literal: true

default['node_exporter']['version'] = '0.17.0'
