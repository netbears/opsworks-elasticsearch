# frozen_string_literal: true

default['heartbeat']['version']                             = '7.2.0'
default['heartbeat']['conf_path']                           = '/etc/heartbeat'
