# frozen_string_literal: true

chef_gem 'aws-sdk' do
  version '~> 2.7'
end
